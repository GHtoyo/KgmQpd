# -*- coding: utf-8 -*-
"""
#############################################################################
KgmQpData

QGISプラグイン版『聞き書きマップ』のデータアクセス処理

【基本方針】（改訂：2021/12/01）
モジュール「kgm-qp」に、QtやQGISエンジンに依存しない部分を集約:

その中心となるクラス「KgmData」に、QtやQGISエンジンから参照されるプロパティや
メソッドを置く。

上記のプロパティは、KgmDataのインスタンス変数として定義し、QtやQGISエンジン
などからは、各プロパティへのアクセッサ経由でのみ扱えるようにする。

2021/11/08-09の方法でGUI窓同士を相互参照するためのポインタ(?)も、KgmQpDataの
インスタンス変数として定義する。

メイン窓の「読み込み」でKGMデータのフォルダが指定されたとき、そのデータフォル
ダに対応するKgmQpDataのインスタンスを作る。

KGMが扱う３つのデータ（＝GPSログ、写真画像・メモ欄テキスト、音声）それぞれに
対する処理も、GUIやGISに直接関わる部分を除き、モジュール「kgm-qp」の中で、３つ
のデータそれぞれに対応するクラスとして定義する。

（Qtによる）GUIやQGISによる地図画面は、KgmQpData（のインスタンス）の内容を表示
する、言わば「ビュー」のようなものとして扱う。
として扱う。

【例外】（2021/11/13）
音声の処理に使うQtMultimediaは（例外的に）ここに含める。
∵ KgmQpDialogのメイン窓・拡大窓で共用する必要がある。

【追記】（2021/12/13）
v.3.10のQgsVectorFileWriter.createにバグがあるため、v.3.16（以降）専用とする。

#############################################################################
"""

import os

##### globライブラリをインポート
import glob    # ディレクトリ内の画像ファイル一覧の取得に使用
import re      # 2021/12/03: globと組み合わせてJPGの大文字小文字問題に対処

##### 2021/12/16: 改行入り文字列リテラル使用のために必要
# https://qiita.com/tag1216/items/3447def88ed6b1d51d60
import textwrap

##### ifaceを使うために必要
#     --> see: PyGIS Developer Cookbook, 1.1
#     (2021/03/19)
from qgis.core import *
import qgis.utils
from qgis.utils import iface
from decorator import __init__

##### Pillow(PIL)ライブラリ読み込み(2021/03/07)
# Anacondaに同梱のPillowは「Python2のPILをフォークしたものらしい」とのこと
# --> see https://kapibara-sos.net/archives/658
from PIL import Image
from PIL.ExifTags import TAGS

##### 2022/03/11: 写真画像に文字を重ねるため追加
# https://www.codegrepper.com/code-examples/python/add+text+to+image+python
from PIL import ImageFont, ImageDraw


##### (2021/03/19)
#      2021/11/13: 音声再生用にQtCoreを追加
from qgis.PyQt import QtCore
from qgis.PyQt.QtCore import QDateTime
from numpy import ix_


##### 音声再生用にPyQt5.QtMultimediaを使う（2021/03/21）
#     2021/11/13: ここに移動＆
from PyQt5 import QtMultimedia
from PyQt5.QtMultimedia import QMediaPlayer
from networkx.classes.function import selfloop_edges

##### kgm_qpd_qgisioモジュールからKgmQpQgisIoクラスをインポート
#     2021/11/11：インポート対象をこれだけに限定
from .kgm_qpd_qgisio import KgmQpQgisIo
from builtins import property


class KgmQpData:
    """
    KGM-Opの各構成部分を橋渡しする基幹部分。以下のものをここで定義・管理：
    １．各構成部分から参照されるインスタンス変数（アクセッサ経由で処理）
    ２．KGM-Qpの各機能を司るメソッドを呼び出す関数「 [#文言再考?]
    """
    
    def __init__(self, mainwindow: object, folderpath: str):
        """ 
        コンストラクタ：
        メイン窓のスレッドから呼ばれるので、以下を引数とする。
        １．mainwindow: 呼び出し側のメイン窓のインスタンス
        ２．folderpath: 呼び出し時に指定された、KGMデータのフォルダへのフルパス
        """
        ##### デバッグモードのフラグをインスタンス変数として定義
        self._debug_mode = 'Y'   # 直接参照できるように隠蔽なしの名称にした
        
        
        ##### KGM-Opの中心的構成部品のインスタンスへの参照 #################
        #     自分自身（KgmQpData）への参照も含む
        #    （インスタンス化時点で参照先が未定のものの初期値は「object」）
        #    （☆「object」については、→ see 柴田2019、p,331）
        self.__my_instance = self               # 自分自身のインスタンス
        self._current_mainwindow = mainwindow  # メイン窓のインスタンス
        self._kgm_qp_mapio = object            # KgmQpQgisIoのインスタンス
        
        ##### ユーザには操作させないインスタンス変数
        self.__kgmqp_root_path = ''       # 本pluginを置くフォルダへのパス
        self.__kgmqp_folderpath = folderpath  # KGMデータのフォルダへのパス
        self.__kgmqp_tlgfile_path = ''    # KgmQpTracklogファイルへのパス
        self.__kgmqp_list_jpgpics = list  # KGMフォルダ内のjpg画像のリスト
        self.__kgmqp_ppsource_path = ''   # KgmQpPhotopointsソースへのパス
        self.__kgmqp_soundfile_path = ''  # 音声ファイルへのパス
        self.__kgmindex_exists = ''       # KGMindex.txtの存否を示すフラグ
        self.__kgmindex_str = ''          # KGMindex.txtの内容を保持
        
        ##### ユーザの操作などで値を変更可能なインスタンス変数
        self.__tlglyr_name = ''                # KgmQpTracklogのレイヤ名
        self.__pplyr_name = ''                 # KgmQpPhotopointsのレイヤ名
        self.__pplyr_fields = list             # 同上の属性フィールド
        self.__current_photo_index = 0         # 表示中のppのインデクス番号
        '''
        self.__current_photo_attributes = list # 表示中のppの属性リスト
        '''
        
        ##### 起動時に値が確定するインスタンス変数に値を設定
        self.__kgmqp_root_path = os.path.join(
                                 QgsApplication.qgisSettingsDirPath(),
                                 'python', 'plugins', 'kgm_qp'
                                 )
        
        
    def amiok(self):
        """ 自分のインスタンスが正しく作られたかの確認 """
        print('【KgmQpData】メイン窓への参照は、' \
              '{} です。'.format(self._current_mainwindow))
        print('【KgmQpData】KGMデータのあるフォルダへのパスは、' \
              '{} です。'.format(self.__kgmqp_folderpath))
        print('【KgmQpData】このpluginのあるフォルダへのパスは、'\
              '{} です。'.format(self.__kgmqp_root_path))
        
        self._current_mainwindow.textEdit.setText('Hello, '\
              'this is an instance of KgmData!')
        
        
    ##### KgmQpData内で管理するインスタンス変数のアクセッサ
    #     （柴田2019, p.320-321）
    
    @property
    def kgmqp_root_path(self) -> str:
        """ 
        【ReadOnly】KgmQp pluginを置くフォルダへのパス
        ここにtracklogやphotopointのスタイルファイルも置く
        """
        return self.__kgmqp_root_path
    
    @property
    def kgmqp_folderpath(self) -> str:
        """ 【ReadOnly】KGMデータのあるフォルダへのパス """
        return self.__kgmqp_folderpath
    
    @property
    def kgmqp_tlgfile_path(self) -> str:
        """ 
        【ReadOnly】KgmQpTracklogファイルへのパス
        　値のセットはprepare_datasets内でのみ実施
        """
        return self.__kgmqp_tlgfile_path
    
    @property
    def kgmqp_list_jpgpics(self) -> list:
        """
        【ReadOnly】KGMデータフォルダ内のjpg画像ファイルのリスト
        　値のセットはprepare_datasets内でのみ実施
        """
        return self.__kgmqp_list_jpgpics
    
    @property
    def kgmqp_ppsource_path(self) -> str:
        """
        【ReadOnly】KgmQpPhotopointsソースへのパス
        　値のセットはprepare_datasets内でのみ実施
        """
        return self.__kgmqp_ppsource_path
    
    @property
    def kgmqp_soundfile_path(self) -> str:
        """
        【ReadOnly】音声ファイルへのパス
        　値のセットはprepare_datasets内でのみ実施
        """
        return self.__kgmqp_soundfile_path
    
    @property
    def kgmindex_exists(self) -> str:
        """
        【ReadOnly】KGMindex.txtの存否を示すフラグ
        　値のセットはprepare_datasets内でのみ実施
        """
        return self.__kgmindex_exists
    
    @property
    def kgmindex_str(self):
        """
        【ReadOnly】KGMindex.txtの内容を保持
        　値のセットはprepare_datasets内でのみ実施
        """
        return self.__kgmindex_str
    
    
    @property
    def tlglyr_name(self) -> str:
        """ GPSトラックログレイヤのレイヤ名のgetter """
        return self.__tlglyr_name    
    
    @tlglyr_name.setter
    def tlglyr_name(self, name: str) -> None:
        """ GPSトラックログレイヤのレイヤ名のsetter """
        self.__tlglyr_name = name
    
    @property
    def pplyr_name(self) -> str:
        """ phoyopointレイヤのレイヤ名のgetter """
        return self.__pplyr_name    
    
    @pplyr_name.setter
    def pplyr_name(self, name: str) -> None:
        """ phoyopointレイヤのレイヤ名のsetter """
        self.__pplyr_name = name
    
    @property
    def pplyr_fields(self):
        """ photopointsレイヤの属性フィールド一覧のgetter """
        return self.__pplyr_fields
    
    @pplyr_fields.setter
    def pplyr_fields(self, flds: list) -> None:
        """ photopointsレイヤの属性フィールド一覧のsetter """
        self.__pplyr_fields = flds
    
    @property
    def current_photo_index(self) -> int:
        """ 写真画像窓に表示される写真のインデクス番号のgetter """
        return self.__current_photo_index
    
    @current_photo_index.setter
    def current_photo_index(self, ix: int) -> None:
        """ 写真画像窓に表示される写真のインデクス番号のsetter """
        self.__current_photo_index = ix
    
    
    def prepare_datasets(self):
        """
        １．KgmQpQgisIoのインスタンスを作りself._kgm_qp_mapioに入れる
        ２．KGMの３種類のデータ各々を処理する４つのクラスのインスタンスを作成
          (1) KgmQpTracklog： GPSトラックログに関する処理を担当
          (2) KgmQpPhotopoints： 写真画像・メモテキストに関する処理を担当
          (3) KgmQpExif： 写真画像のEXIF情報に関する処理を担当
          (4) KgmQpSound： 音声に関する処理を担当
        ３．KGMデータフォルダ内を検索し、以下の値をセット
          (1)KgmQpTracklogファイルへのパス
          (2)写真画像のjpgファイル名リスト
          (3)KgmQpPhotopointsソースへのパス
          (4)KGMindex.txt（あれば）内の録音開始時刻文字列
          (5)音声ファイルへのパス
        ４．QGISに以下のレイヤを作成または既存のものに設定
        　(1)KgmQpTracklogレイヤ
        　(2)KgmQpPhotopointsレイヤ
        """
        
        ##### １．KgmQpQgisIoのインスタンスを作り、
        #    自分自身のインスタンスへの参照を渡す
        #    変数名は「_kgm_qp_mapio」と一般的な名称にする
        self._kgm_qp_mapio = KgmQpQgisIo(self.__my_instance)
        
        if self._debug_mode == 'Y':
            print('【KgmQpData】KgmQpQgisIoのインスタンスへの参照は、'\
                  '{} です。'.format(self._kgm_qp_mapio))
            self._kgm_qp_mapio.amiok()
        
        ##### ２-(1) KgmQpTracklogのインスタンスを作り、
        #    自分自身のインスタンスへの参照を渡す
        self.kgm_tlg_inst = KgmQpTracklog(self.__my_instance,
                                          self._kgm_qp_mapio)
        
        if self._debug_mode == 'Y':
            self.kgm_tlg_inst.amiok()
        
        ##### ２-(2) KgmQpPhotopointsのインスタンスを作り、
        #    自分自身のインスタンスへの参照を渡す
        self.kgm_pp_inst = KgmQpPhotopoints(self.__my_instance,
                                            self._kgm_qp_mapio)
        
        if self._debug_mode == 'Y':
            self.kgm_pp_inst.amiok()
        
        ##### ２-(3) KgmQpExifのインスタンスを作り、
        #    自分自身のインスタンスへの参照を渡す
        self.kgm_exif_inst = KgmQpExif(self.__my_instance)  
        
        ##### ２-(4) KgmQpSoundのインスタンスを作り、
        #    自分自身のインスタンスへの参照を渡す
        # self.kgm_snd_inst = KgmQpSound(self.__my_instance)
        
        '''
        ##### 2022/03/06: 複数データ時の音声重複再生への対策
        try:
            del self.kgm_snd_inst
        except:
            print('【KgmQpData】既存のsdel self.kgm_snd_instはありません。')
        finally:
            self.kgm_snd_inst = KgmQpSound(self.__my_instance)
        '''
        
        self.kgm_snd_inst = KgmQpSound(self.__my_instance)
        
        if self._debug_mode == 'Y':
            self.kgm_snd_inst.amiok()
        
        ##### ３-(1) KgmQpTracklogファイルへのパスをセット
        self.__kgmqp_tlgfile_path = self.kgm_tlg_inst.set_kgmqp_tlgfile_path()
        if self._debug_mode == 'Y':
            print('【KgmQpData】Tracklogファイルへのパスは、'\
                  '{} です。'.format(self.kgmqp_tlgfile_path))
        
        ##### ３-(2) 写真画像のjpgファイル名リストをセット
        self.__kgmqp_list_jpgpics = self.kgm_pp_inst.set_kgmqp_list_jpgpics() 
        if self._debug_mode == 'Y':
            print('【KgmQpData】画像ファイル名のリストは、'\
                  '{} です。'.format(self.kgmqp_list_jpgpics))
        '''
        ##### ３-(3) KgmQpPhotopointsソースへのパスをセット
        self.__kgmqp_ppsource_path = self.kgm_pp_inst.set_kgmqp_ppsource_path()
        if self._debug_mode == 'Y':
            print('【KgmQpData】Photopointsソースへのパスは、'\
                  '{} です。'.format(self.kgmqp_ppsource_path))
        '''
            
        ##### ３-(4) KGMindex.txt（あれば）内の録音開始時刻文字列をセット
        kgmindex_path = os.path.join(
                                self.kgmqp_folderpath,
                                'KGMindex.txt')
        # KGMindex.txtのオープンを試み、
        # 成功ならその内容をインスタンス変数にセットしフラグを'Y'に
        # エラーならインスタンス変数を''としフラグを'N'に
        try:
            kgmindex_txtfile = open(kgmindex_path,
                                    "r",
                                    encoding="utf_8",
                                    errors="",
                                    newline="" )
        except:
            self.__kgmindex_str = ''
                # KGMindex.txtの内容を読み込む
            self.__kgmindex_exists = 'N'
                # 存否フラグを'Y'に
        
        else:
            self.__kgmindex_str = kgmindex_txtfile.read()
                # KGMindex.txtの内容を読み込む
            self.__kgmindex_exists = 'Y'
                # 存否フラグを'Y'に
        
        if self._debug_mode == 'Y':
            print('KGMindex.txtの存否 = '\
                  '{}'.format(self.kgmindex_exists))
            print('KGMindex.txtの内容 = '\
                  '{}'.format(self.kgmindex_str))
        
        ##### ３-(5) 音声ファイルへのパスをセット
        self.__kgmqp_soundfile_path = self.kgm_snd_inst.prepare_sound_data()
        
        
        ##### ４-(1) KgmQpTracklogレイヤを設定
        self.tlglyr_name = self.kgm_tlg_inst.set_kgmqp_tlglayer(
                                                self.kgmqp_tlgfile_path)
        
        if self._debug_mode == 'Y':
            print('self.kgmqp_tlgfile_pathの値 = '\
                  '{}'.format(self.kgmqp_tlgfile_path))
            print('self.tlglyr_nameの値 = '\
                  '{}'.format(self.tlglyr_name))
        
        
        ##### ３-(3) KgmQpPhotopointsソースへのパスをセット
        self.__kgmqp_ppsource_path = self.kgm_pp_inst.set_kgmqp_ppsource_path()
        if self._debug_mode == 'Y':
            print('【KgmQpData】Photopointsソースへのパスは、'\
                  '{} です。'.format(self.kgmqp_ppsource_path))
        
        
        
        ##### ４-(2) KgmQpPhotopointsレイヤを設定
        self.pplyr_name = self.kgm_pp_inst.set_kgmqp_pplayer(
                                                self.kgmqp_ppsource_path)
        
        
        '''
        ##### ３-(3) KgmQpPhotopointsソースへのパスをセット
        self.__kgmqp_ppsource_path = self.kgm_pp_inst.set_kgmqp_ppsource_path()
        if self._debug_mode == 'Y':
            print('【KgmQpData】Photopointsソースへのパスは、'\
                  '{} です。'.format(self.kgmqp_ppsource_path))
        '''
        
        
        
    
    
    ##### 2021/11/15: メイン窓のボタン（など）の操作に対応する処理
    def button_sound_forward(self):
        """  音声を〇秒進める"""
        milisec = self.kgm_snd_inst.player.position() + \
                  self.kgm_snd_inst.foward_backward_seconds*1000
        # 頭出しして再生
        self.kgm_snd_inst.player.setPosition(milisec)
        self.kgm_snd_inst.player.play()
        
    def button_sound_backward(self):
        """  音声を〇秒戻す"""
        milisec = self.kgm_snd_inst.player.position() - \
                  self.kgm_snd_inst.foward_backward_seconds*1000
        # 頭出しして再生
        self.kgm_snd_inst.player.setPosition(milisec)
        self.kgm_snd_inst.player.play()
    
    def button_sound_stop(self, labeltext: str) -> str:
        """ 音声再生を停止・再開 """
        
        if (self.kgm_snd_inst.player.state() == QMediaPlayer.PlayingState):
            self.kgm_snd_inst.player.pause()
            labeltext = '再開'
        elif (self.kgm_snd_inst.player.state() == QMediaPlayer.PausedState):
            self.kgm_snd_inst.player.play()
            labeltext = '停止'
        else:
            self.kgm_snd_inst.player.stop()
            labeltext = '【終了】'
        
        return labeltext
        
    def button_sound_listen_again(self):
        """ もう一度聞く """
        milisec = self.kgm_snd_inst.sound_elapsed_milisec_adjusted
        # 頭出しして再生
        self.kgm_snd_inst.player.setPosition(milisec)
        self.kgm_snd_inst.player.play()
    
    def button_pic_next(self) -> list:
        """ 「次の写真へ」 """
        
        int_max = len(self.kgmqp_list_jpgpics)
        # print(".jpgファイルの総数は、", int_max, "個です。")
        if self.current_photo_index >= int_max - 1:
            self.current_photo_index = int_max - 1
        else:
            self.current_photo_index += 1          # incliment
        
        self.kgm_pp_inst.zoom_to_selected_point()
        self.kgm_snd_inst.play_sound(self.current_photo_index)
        pp_attrlist = \
            self.current_photo_attributes(self.current_photo_index)
        
        return pp_attrlist
        
    
    def button_pic_previous(self) -> list:
        """ 「前の写真へ」 """
        
        int_max = len(self.kgmqp_list_jpgpics)
        # print(".jpgファイルの総数は、", int_max, "個です。")
        if self.current_photo_index >= int_max - 1:
            self.current_photo_index = int_max - 1
        elif self.current_photo_index <= 0:
            self.current_photo_index = 0           # 0が最小
        else:
            self.current_photo_index -= 1          # decliment
        
        self.kgm_pp_inst.zoom_to_selected_point()
        self.kgm_snd_inst.play_sound(self.current_photo_index)
        pp_attrlist = \
            self.current_photo_attributes(self.current_photo_index)
        
        return pp_attrlist
    
    def button_kml_export(self, path: str) -> None:
        """ 「KML出力」ボタンクリック時の処理 """
        
        ##### 2021/12/16: Chromebook用のKML（いずれはKMZ）出力
        if self._debug_mode == 'Y':
            print('【KgmQpData】「KML出力」ボタンがクリックされました。')
        
        
        ##### kml_tracklog_str = self._kgm_qp_mapio.s2k_tracklog()
        kml_photopoint_str = self._kgm_qp_mapio.s2k_photopoints()
    
    def button_jamboard_export(self, path: str) -> None:
        """
        「写真印刷」ボタンクリック時の処理
        ☆2022/02/26: 当面は、JamBoard用画像ファイルの書き出し
        
         """
        if self._debug_mode == 'Y':
            print('【KgmQpData】「写真印刷」ボタンがクリックされました。')
        
        map_image_name = self.pplyr_name + \
                        '_撮影地点_' + \
                        str(self.current_photo_index) + \
                        '_地図.png'
        fullpath_map = os.path.join(path, map_image_name)
        self._kgm_qp_mapio.save_map_as_image(fullpath_map)
        
        jb_image = self.compose_jb_image(self.kgmqp_folderpath, self.current_photo_index)
        
        jb_image_name = self.pplyr_name + \
                        '_撮影地点_' + \
                        str(self.current_photo_index) + \
                        '_写真.jpg'
        fullpath_jb_image = os.path.join(path, jb_image_name)
        jb_image.save(fullpath_jb_image)
    
    def compose_jb_image(self, pp_pic_folder: str, ix: int) -> object:
        """
        【2022/03/11】
        現在表示中の写真にID番号を付加した画像を作成
        """
        cpa = self.current_photo_attributes(ix)
        pp_pic_filename = cpa[1]
        pp_pic_fullpath = os.path.join(pp_pic_folder, pp_pic_filename)
        
        my_image = Image.open(pp_pic_fullpath)
        
        
        resized_image = my_image.resize((640,480))
        
        # title_font = ImageFont.truetype('font.ttf', 200)
        
        # use a bitmap font
        # https://pillow.readthedocs.io/en/stable/reference/ImageFont.html
        # title_font = ImageFont.load("arial.pil")
        # title_font = PIL.ImageFont.load_default()
        ### 【これはOKだが小さい】title_font = ImageFont.load_default()
        ### 【これはNG!】title_font = ImageFont.truetype('Arial', 20)
        title_font = ImageFont.load_default()
        
        image_editable = ImageDraw.Draw(resized_image)
        # image_editable.text((15,15), str(ix), (237, 230, 211), font=title_font)
        image_editable.rectangle([(0, 0), (50, 50)], (255, 255, 255), (0, 0, 0), 3)
        image_editable.text((20,20), str(ix), (0, 0, 0), title_font, None, None,"center")
        
        return  resized_image
    
    def current_photo_attributes(self, ix: int) -> list:
        """ 表示中のphotopointの属性リストを返す """
        pp_attrlist = self._kgm_qp_mapio.sp_feature_attributes(ix)
        return pp_attrlist
    
    
    def photopoint_to_be_shown_update(self):
        """
        【2022/02/15】地図上のphotopointクリックによる表示の更新
        （当座）メイン窓のshow_kgm_pic_attrで実施
        （当座）メイン窓の写真ID番号表示欄（lineEdit）の更新で
                拡大窓にも反映
        　☆事前にself.current_photo_indexを更新しておく！
        """
        
        cpa = self.current_photo_attributes(self.current_photo_index)
        self._current_mainwindow.show_kgm_pic_attr(cpa)
        
        ##### 2022/03/04:【要修正】ここで直接lineEdit_PicIDに書き込む是非
        self._current_mainwindow.lineEdit_PicID.setText(
                                           str(self.current_photo_index)
                                           )
        self.kgm_pp_inst.zoom_to_selected_point()
        self.kgm_snd_inst.play_sound(self.current_photo_index)



class KgmQpTracklog:
    """ KGMのトラックログ処理クラス """
    
    def __init__(self, coredata:object, mapio: object):
        """ 
        コンストラクタ：
        
        """
        
        self._kgm_qp_coredata = coredata
        self._kgm_qp_mapio = mapio     # KgmQpQgisIoのインスタンスへの参照
        
        
    def amiok(self):
        print('【KgmQpTracklog】KgmQpQgisIoのインスタンス参照は、'\
              '{} です。'.format(self._kgm_qp_mapio))
        
    
    def set_kgmqp_tlgfile_path(self) -> str:
        str_glob_target = os.path.join(
                          self._kgm_qp_coredata.kgmqp_folderpath,
                          '*.gpx')
        try:
            list_gpxfile_fullpath = glob.glob(str_glob_target)
        except:
            ##### 2022/02/19: 今後、ファイルなしなどのエラー処理を追記
            pass
        else:
            if len(list_gpxfile_fullpath) > 1:
                ##### 2022/02/19: 今後、一覧から選ばせる処理を追記
                print('【KgmQpTracklog】gpxファイルが複数あります：'\
                      '{} '.format(list_gpxfile_fullpath))
            else:
                tlgfile_path = list_gpxfile_fullpath[0]
        finally:
            print('【KgmQpTracklog】gpxファイルへのパスは、'\
                  '{} です。'.format(tlgfile_path))
            return tlgfile_path
    
    def set_kgmqp_tlglayer(self, tlgfile_path: str) -> str:
        """ KgmQpTracklogレイヤを作成・設定してレイヤ名を返す """
        tlgfile_name = os.path.basename(tlgfile_path)
        tlglayer_name = self._kgm_qp_mapio.set_tracklog_layer(tlgfile_name)
        return tlglayer_name
    
    
    
class KgmQpPhotopoints:
    """ KGMの写真画像＋メモ文字列処理クラス """    
    
    def __init__(self, coredata: object, mapio: object):
        """ 
        コンストラクタ：
        
        """
        
        self._kgm_qp_coredata = coredata
        self._kgm_qp_mapio = mapio     # KgmQpQgisIoのインスタンスへの参照
    
    def amiok(self):
        print('【KgmQpPhotopoints】KGMデータのあるフォルダへのパスは、'\
              '{} です。'.format(self._kgm_qp_coredata.kgmqp_folderpath))
        
    
    def set_kgmqp_list_jpgpics(self) -> list:
        """ 写真画像のjpgファイル名リストを返す """
        
        list_jpgpics = []
        
        
        # 2021/12/03: Macでは大文字・小文字を区別してエラーになるので書き換えた
        #     まずstr_kgmq_dir_pathフォルダ内の全ファイルをglobでリストし、
        #     ついでリスト内包表記でextが'.jpg'または'.JPG'のものを抽出、
        #     その後（当面）地味にループでパスなしファイル名の空リストに追加。
        #     ☆【要注意！】'.*\.(jpg|JPG)'のアスタリスク前のピリオドは必須！
        str_glob_target = os.path.join(self._kgm_qp_coredata.kgmqp_folderpath,
                                       '*.*')
        list_jpgpics_fullpath = \
                [fp for fp in glob.glob(str_glob_target) \
                 if re.search('.*\.(jpg|JPG)', str(fp))]
        for file in sorted(list_jpgpics_fullpath):
                # ファイル名（ソートずみ）のリストを作成
            filanameonly = os.path.basename(file)
            list_jpgpics.append(filanameonly)
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('抽出した写真のリストは、{} です。'.format(list_jpgpics))
        
        return list_jpgpics
    
    def set_kgmqp_ppsource_path(self) -> str:
        """ KgmQpPhotopointsソースへのパスをセット """
        str_glob_target = os.path.join(self._kgm_qp_coredata.kgmqp_folderpath,
                                       '*.shp')
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【KgmQpPhotopoints】str_glob_targetの値は、'\
                  '{}です。'.format(str_glob_target))
            
        try:
            list_shpfile_fullpath = glob.glob(str_glob_target)
            if self._kgm_qp_coredata._debug_mode == 'Y':
                print('【KgmQpPhotopoints】list_shpfile_fullpathの値は、'\
                      '{}です。'.format(list_shpfile_fullpath))
        except:
            ##### 2022/02/24: globはtargetが見つからないと[]を返す
            #                 ie.エラーにはならない
            pass
        else:
            if len(list_shpfile_fullpath) == 0:
                #### 2022/02/24: shpファイル・ppレイヤを新規作成
                layer_name = self._kgm_qp_mapio.create_point_shape_layer()
                list_shpfile_fullpath = glob.glob(str_glob_target)
                if self._kgm_qp_coredata._debug_mode == 'Y':
                    print('【新規作成後】list_shpfile_fullpathの値は、'\
                          '{}です。'.format(list_shpfile_fullpath))
                ppsource_path = list_shpfile_fullpath[0]
            elif len(list_shpfile_fullpath) > 1:
                ##### 2022/02/19: 今後、一覧から選ばせる処理を追記
                print('【KgmQpPhotopoints】shpファイルが複数あります：'\
                      '{} '.format(list_shpfile_fullpath))
            else:
                ppsource_path = list_shpfile_fullpath[0]
        finally:
            print('【KgmQpPhotopoints】shpファイルへのパスは、'\
                  '{} です。'.format(ppsource_path))
            return ppsource_path
    
    
    def set_kgmqp_pplayer(self, ppsource_path: str) -> str:
        """ Photopointのレイヤを作成・設定してレイヤ名を返す """
        ppsource_name = os.path.basename(ppsource_path)
        pplayer_name = self._kgm_qp_mapio.set_pp_layer(ppsource_name)
        return pplayer_name
    
    def get_pplyr_fields(self):
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【KgmQpPhotopoints】photopointのレイヤ名は、'\
                  '{}です。'.format(self._kgm_qp_coredata.pplyr_name))
            
        pplyr_fields = \
            self._kgm_qp_mapio.get_fields(self._kgm_qp_coredata.pplyr_name)
        
        return pplyr_fields
    
    def zoom_to_selected_point(self):
        """ 2021/11/15: 表示中のphotopointの地点にズーム """
        
        layer_name = self._kgm_qp_coredata.pplyr_name
        ix = self._kgm_qp_coredata.current_photo_index
        attrlist = self._kgm_qp_coredata.current_photo_attributes(ix)
        picid = attrlist[0]
        layer = self._kgm_qp_mapio.select_pp_layer(layer_name)
        layer.selectByExpression('"pic_id" = ' + str(picid))
        
        box = layer.boundingBoxOfSelected()
        iface.mapCanvas().setExtent(box)
        # 【2022/02/15: 一時的にコメントアウト】iface.mapCanvas().refresh()
    
    def get_memotext_of_photopoint(self, ix: int) -> str:
        """ 
        現在参照中のphotopointレイヤの属性テーブルを読んで、
        current_photo_attributesを更新し、
        そのフィールド[2]にあるテキストを返す
        """
        
        attrlist = self._kgm_qp_mapio.sp_feature_attributes(ix)
        txt = attrlist[2]              # メモテキストはフィールド[2]
        return txt
    
    def set_memotext_of_photopoint(self, ix: int,  txt: str) -> None:
        """ 
        引数のテキストを、photopointの、引数ixのフィーチャの、
        属性テーブル（の該当フィールド）に書き込む
        
        """
        self._kgm_qp_mapio.set_photopoint_memotext(ix, txt)
        
        return


class KgmQpExif:
    """ 寫眞のEXIF情報を処理するクラス"""
    def __init__(self, coredata: object):
        """
        コンストラクタ
        """
        
        self._kgm_qp_coredata = coredata
        
    def get_exif_of_image(self, jpgpic_path: str) -> list:
        """
        写真のEXIF情報をテーブルとして取得
        Get ESIF of an image if exists.
        指定した画像のEXIFデータを取り出す関数
        @return exif table Exif --- データを格納した辞書
        """
        im = Image.open(jpgpic_path)
        
        # Exifデータを取得
        # 存在しなければそのまま終了、空の辞書を返す。
        try:
            exif = im._getexif()
        except AttributeError:
            return{}
            
        # タグIDそのままでは人が読めないのででコードして
        # テーブルに格納する。
        exif_table = {}
        for tag_id, value in exif.items():
            tag = TAGS.get(tag_id, tag_id)
            exif_table[tag] = value
            
        return exif_table
    
    
    def get_datetime_of_image(self, jpgpic_path: str) -> str:
        """ 取得したEXIfテーブルから撮影日時を取り出す
            Get date-time of an image if exists
            指定した画像のEXIFデータのうち撮影日時データを取り出す
            @return yyyy:mm:dd HH:MM:SS 形式の文字列
            """
        
        # get_esif_of_imageの戻り値のうち
        # 日付時刻データのみを取得して返す
        exif_table = self.get_exif_of_image(jpgpic_path)
        datetime_original = exif_table.get("DateTimeOriginal")
        return datetime_original
    
    
    def conv_exifdt_to_gpxdt(self, str_exifdt: str) -> str:
        """EXIFのDateTimeをGPXのDateTime(UTC)に変換 """
        exif_year = int(str_exifdt[0:4])
        exif_month = int(str_exifdt[5:7])
        exif_day = int(str_exifdt[8:10])
        exif_hour = int(str_exifdt[11:13])
        exif_minute = int(str_exifdt[14:16])
        exif_second = int(str_exifdt[17:19])
                
        qdt = QDateTime(exif_year,
                        exif_month,
                        exif_day, exif_hour,
                        exif_minute,
                        exif_second,
                        timeSpec=0)
        qdt_utc = QDateTime(qdt.toUTC())
        str_qdt_utc = qdt_utc.toString('yyyy-MM-ddThh:mm:ss.000')
        
        return str_qdt_utc


class KgmQpSound:
    """ KGMの音声データ処理クラス """    
    
    def __init__(self, coredata: object):
        """ 
        コンストラクタ：
        
        """
        
        self._kgm_qp_coredata = coredata
        
        '''
        ##### QtMultimedia.QMediaPlayeをインスタンス変数に設定
        try:
            self.player.stop()
        except:
            print('【KgmQpSound】既存のself.playerはありません。')
        else:
            del self.player   # 既存のがあれば消す
        finally:
            self.player = QMediaPlayer()
        
        '''
        
        self.player = QMediaPlayer()
        
        # 音声のファイル名と開始時点の日時をインスタンス変数に保持
        # 初期値は無名・システムの現在時刻
        self.str_kgm_sound_filename = ''     # 音声ファイルのファイル名
        self.sound_start_datetime = QDateTime.currentDateTime()
        
        # 音声データの伸縮を調整するの係数をインスタンス変数に保持
        # （2021/03/22）
        # self.adjust_coeff = 0.885        
        self.adjust_coeff = 1.000   # KGM-i用に1.000に戻した (2021/05/29)
        
        # 音声を「進める」「戻す」ボタンの秒数をインスタンス変数に保持
        self.foward_backward_seconds = 3
        
        # 撮影時刻までの（調整後）経過時間もインスタンス変数に保持
        # （2021/03/25）
        self.sound_elapsed_milisec_adjusted = 0
        
        
        
    def amiok(self):
        print('【KgmQpSound】KGMデータのあるフォルダへのパスは、'\
        '{} です。'.format(self._kgm_qp_coredata.kgmqp_folderpath))
        
    def prepare_sound_data(self):
        """  """
        # QtMultimedia.QMediaPlayerで再生する音声ファイルを準備（2021/03/21）
        # 2021/11/13: KgmQpSound内への配置に伴いリライト
        self.str_kgm_sound_filename = \
            self.get_sound_filename(self._kgm_qp_coredata.kgmqp_folderpath)
        
        snd_content = self.get_sound_content(self.str_kgm_sound_filename)
        self.player.setMedia(snd_content)
        self.sound_start_datetime = self.get_start_datetime_of_sound(
                        self._kgm_qp_coredata.kgmqp_folderpath,
                        self.str_kgm_sound_filename
                        )
        
    def get_sound_filename(self, str_kgmq_dir_path):
        """ 
        【wav・mp3形式に対応】KGMの音声ファイルのファイル名を返す
        """
        list_sound_files = []
        
        # 2021/12/26: iPhone(WAV)・Android(MP3)の両方に対応するように修正
        #     まずstr_kgmq_dir_pathフォルダ内の全ファイルをglobでリストし、
        #     ついでリスト内包表記でextが'.WAV''.wav'.MP3''.mp3'のものを抽出。
        #     ☆【要注意！】'.*\.(WAV|wav|MP3|mp3)'の「＊」前のピリオドは必須！
        #     ☆【要注意！】区切り記号は「|」であり「/」ではない！
        #                 （イタリックだと見分けにくい）
        str_glob_target = os.path.join(str_kgmq_dir_path, '*.*')
        list_sound_files_fullpath = [fp for fp in \
                                     glob.glob(str_glob_target) \
                                     if re.search('.*\.(WAV|wav|MP3|mp3)',
                                                  str(fp))]
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【get_sound_filename】list_sound_files_fullpathの値は、'\
            '{}です。'.format(list_sound_files_fullpath))  
        
        str_sound_filename = os.path.basename(list_sound_files_fullpath[0])
            # 当面サウンドファイルは１つと前提
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【get_sound_filename】str_sound_filename = '\
                  '{}'.format(str_sound_filename))      
        
        return str_sound_filename
    
    def get_sound_content(self, str_sound_filename):
        """ 
        KGMの音声ファイルをQtMultimedia.QMediaPlayerで開く（2021/03/21）
        """
        
        str_sound_filepath = os.path.join(
                                self._kgm_qp_coredata.kgmqp_folderpath,
                                self.str_kgm_sound_filename)
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print("str_sound_filepath = ", str_sound_filepath)
            
        s_media = QtCore.QUrl.fromLocalFile(str_sound_filepath)
        # s_content = qgis.PyQt5.QtMultimedia.QMediaContent(s_media)
        s_content = QtMultimedia.QMediaContent(s_media)
        # self.sound_media = s_media
        # self.sound_content = s_content
        
        return(s_content)
    
    def get_start_datetime_of_sound(self,
                                    str_folder_path,
                                    str_sound_filename):
        """
        音声ファイルのフォルダ名・ファイル名から録音開始時刻情報を取得、
        self.sound_start_datetimeに入れる
        """        
        str_soundfile_basename = os.path.basename(str_sound_filename)
        
        if self._kgm_qp_coredata.kgmindex_exists == 'N':
            ##### 【要修正！】KGMindex.txtがなければ、
            # Abliedaのファイル名などから腰だめで情報を取得 (2021/05/29)
            # snd_year = int(str_folder_path[0:0])
            # snd_month = int(str_folder_path[0:0])
            snd_year = 2021     # とりあえず2021年
            # snd_month = 2      # とりあえず2月
            snd_month = 3      # とりあえず3月に変更（2021/03/22）
            snd_day = int(str_soundfile_basename[0:2])
            snd_hour = int(str_soundfile_basename[2:4])
            snd_minute = int(str_soundfile_basename[4:6])
            snd_second = int(str_soundfile_basename[6:8])
            ssdt = QDateTime(snd_year,
                             snd_month,
                             snd_day,
                             snd_hour,
                             snd_minute,
                             snd_second,
                             timeSpec=0)            
        elif self._kgm_qp_coredata.kgmindex_exists == 'Y':
            ##### 2021/11/27：
            # 【今後要修正】当面はKGMindex.txtから「"」を除去して処理
            #  Android版とiOSバントのKGMindex.txtの仕様の不統一に対処
            str_temp = self._kgm_qp_coredata.kgmindex_str
            kgmindex_str_temporary = str_temp.strip('"')
            
            ##### 録音開始日時を「YYYY/MM/DD hh:mm:ss」から切り出す
            #     部分文字列のインデクスは、終了文字「の次」まで！
            snd_year = int(kgmindex_str_temporary[0:4])
            snd_month = int(kgmindex_str_temporary[5:7])
            snd_day = int(kgmindex_str_temporary[8:10])
            snd_hour = int(kgmindex_str_temporary[11:13])
            snd_minute = int(kgmindex_str_temporary[14:16])
            snd_second = int(kgmindex_str_temporary[17:19])
            qdt_utc = QDateTime(snd_year,
                                snd_month,
                                snd_day,
                                snd_hour,
                                snd_minute,
                                snd_second,
                                timeSpec=1)
            # KGMindex.txtに記録された時刻はGPSから取得したものなので、
            # timeSpecが「1」(=UTC) (2021/05/29)
            # ちなみに、「timeSpec」が正しい大小文字遣いらしい。
            # 「TimeSpec」ではエラーになった(!) (2021/05/29)
            if self._kgm_qp_coredata._debug_mode == 'Y':
                print('KGMindex.txtから取得した録音開始時刻（UTC） = '\
                  '{}'.format(qdt_utc.toString('yyyy/MM/dd hh:mm:ss')))
            
            ssdt = QDateTime(qdt_utc.toLocalTime())
            
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('Local Timeに変換後の録音開始時刻 = '\
                  '{}'.format(ssdt.toString('yyyy/MM/dd hh:mm:ss')))
        
        return ssdt

    def get_elapsed_time_in_milisec(self, str_exifdt):
        """ 
        写真のEXIFのDateTimeから音声の経過時間（ミリ秒）を産出（2021/03/21）
        追ってExifDateTimeからQDateTimeにする部分は独立の関数にしたい
        """
        exif_year = int(str_exifdt[0:4])
        exif_month = int(str_exifdt[5:7])
        exif_day = int(str_exifdt[8:10])
        exif_hour = int(str_exifdt[11:13])
        exif_minute = int(str_exifdt[14:16])
        exif_second = int(str_exifdt[17:19])
        
        dt_exif = QDateTime(exif_year,
                            exif_month,
                            exif_day,
                            exif_hour,
                            exif_minute,
                            exif_second,
                            timeSpec=0)
        
        dt_elapsed_ms = (self.sound_start_datetime.secsTo(dt_exif))*1000
        
        return dt_elapsed_ms
        
    def play_sound(self, ix: int):
        """
        音声を頭出しして再生
        """
        
        # 【要検討】写真画像のインデクスはKgmQpDataのインスタンス変数から取得
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【KgmQpSound】self._kgm_qp_coredata.current_photo_index'\
                  'の値は、{} です。'\
                  .format(self._kgm_qp_coredata.current_photo_index))
        
        attrlist = self._kgm_qp_coredata.current_photo_attributes(ix)   
        str_exif_datetime = attrlist[3]    # フィールド[3]が撮影時刻
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【KgmQpSound】KgmQpPhotopointsでshapefileから取得した'\
                  'EXIF時刻は、'\
                  '{} です。'.format(str_exif_datetime))
        
        # 調整係数を掛ける（2021/03/22）
        sound_cue_milisec = self.get_elapsed_time_in_milisec(str_exif_datetime)
        adjusted_float = sound_cue_milisec * self.adjust_coeff
        adjusted_cue_milisec = int(adjusted_float)
        
        ### 録音開始時刻、Exif時刻、経過時間をログに書き出す（2021/03/22）
        str_start_time = self.sound_start_datetime.toString('hh:mm:ss')
        str_pic_filename = attrlist[2]     # フィールド[2]が写真ファイル名
        str_exif_time = str_exif_datetime[10:19]
        str_adjust_coeff = str(self.adjust_coeff)
        str_cue_milisec = str(adjusted_cue_milisec)
        
        print('【録音開始】' + str_start_time + '； ' + \
              '【写真：' + str_pic_filename + \
              'のExif時刻】' + str_exif_time + '； ' + \
              '【調整係数】' + str_adjust_coeff + '； ' + \
              '【経過ミリ秒】' + str_cue_milisec)
        
        ##### 2022/03/04: 【要修正】ここでdockwidget上のオブジェクトをいじるのはNG！
        # v010のGUIに（調整後）経過ミリ秒を表示（2021/03/25）
        self._kgm_qp_coredata._current_mainwindow.label_ElapsedTime.setText(
                '【撮影時刻までの経過時間（調整後：ミリ秒）】＝ ' + 
                str_cue_milisec)
        
        # 調整後経過時間をインスタンス変数に保持
        # （2021/03/25：後日用見直し？）
        self.sound_elapsed_milisec_adjusted = adjusted_cue_milisec
            
        # 頭出しして再生
        self.player.setPosition(adjusted_cue_milisec)
        self.player.play()
    
    def delete_player(self):
        """
        self.playerを止めて消す
        """
        ##### 2022/03/06: 複数データ時の音声重複再生への対策
        try:
            self.player.stop()
        except:
            print('【delete_player】既存のself.playerはありません。')
        else:
            del self.player   # 既存のがあれば消す



