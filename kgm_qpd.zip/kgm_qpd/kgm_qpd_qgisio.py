# -*- coding: utf-8 -*-
"""
############################################################
KgmQpQgisIo

QGISプラグイン版『聞き書きマップ』のQGIS-IO処理
方針：データアクセス系・（Qtなどによる）ビュー系と切り分ける

as of 2021/11/05
############################################################
"""

import os

##### ifaceを使うために必要
#     --> see: PyQGIS Developer Cookbook, 1.1
#     (2021/03/19)
from qgis.core import *
import qgis.utils
from qgis.utils import iface
from decorator import __init__
from builtins import classmethod

##### 2021/12/16: 改行入り文字列リテラル使用のために必要
# https://qiita.com/tag1216/items/3447def88ed6b1d51d60
import textwrap

##### 【NG】2021/12/13: QgsMapCanvasを試す
from qgis.gui import (
    QgsMapCanvas,
    QgsVertexMarker,
    QgsMapCanvasItem,
    QgsRubberBand,
    )


##### point shapeファイル作成に使用
#     --> see: PyQGIS_shapefileレイヤ作成テスト_20210315_
#              直接地物から_take2.txt
from qgis.PyQt.QtCore import QVariant


# 2021/11/06: KgmQpDataクラスおよびその派生クラスをインポート
# 2021/11/11: これを一旦ヤメにしていたが、復活
#             ∵KgmQpQgisIoの側がKgmQpDataを知り、その求めに
#               応えるのが筋
from .kgm_qpd_core import *
from pandas._config.config import pp_options_list


##### 2021/12/25: KMZ出力用にsimplekmlを使う
import simplekml

##### 2022/02/26: JamBoard用写真のコピー・リネームに使用（暫定）
import shutil


##### 2021/11/11: KgmQpQgisIoでは全てをフラットなインスタンス
#                 変数・メソッドに統一

class KgmQpQgisIo:
    """
    KGMのデータとQGISのshapefile・レイヤなどとを紐付ける
    """
    ##### 2021/11/05: KGMで扱う写真画像・メモ文字列などを
    # 標準の（KgmQpDataの）インスタンス属性として扱えるように。
    
    
    def __init__(self, kgm_qp_dt_inst: object):
        """ 
        コンストラクタ：
        kgm_qp_dt_inst：KgmQpDataのインスタンス
        """
        self._kgm_qp_data_instance = kgm_qp_dt_inst
        
        ##### 2021/12/05: 
        #     KgmQpQgisioではQgisのレイヤ（=object）自体を管理
        #     それらへのアクセスは、アクセッサ経由に限定
        #     それらの名称（レイヤ名）は、KgmQpData側で管理
        self.__kgmtlg_layer = object
        self.__kgmpic_layer = object
        
        ##### 2022/02/15: QGIS上での操作によるイベント駆動
        # self.__pp_selected_fid = False
        # ↑これはそもそもリストとして定義する要あり
        self.__pp_selected_fids = []
        
    @property
    def kgmtlg_layer(self) -> object:
        """ KGMのトラックログレイヤのgetter """
        return self.__kgmtlg_layer
    
    @kgmtlg_layer.setter
    def kgmtlg_layer(self, layer: object) -> None:
        """ KGMのトラックログレイヤのsetter """
        self.__kgmtlg_layer = layer
        
        ##### 2022/03/06: 
        #    【kgmtlg_layerセットの時点で起動】
        #     レイヤ表示名の変更によるイベント駆動
        self.__kgmtlg_layer.nameChanged.connect(
            self.tplayer_nameChangedSlot)
    
    @property
    def kgmpic_layer(self) -> object:
        """ KGMのphotopointレイヤのgetter """
        return self.__kgmpic_layer
    
    @kgmpic_layer.setter
    def kgmpic_layer(self, layer: object) -> None:
        """ KGMのphotopointレイヤのsetter """
        self.__kgmpic_layer = layer
        
        ##### 2022/02/15: 
        #    【kgmpic_layerセットの時点で起動】
        #     QGIS上での操作によるイベント駆動
        self.__kgmpic_layer.selectionChanged.connect(
            self.pplayer_selectionChangedSlot)
        
        ##### 2022/03/06: 
        #    【kgmpic_layerセットの時点で起動】
        #     レイヤ表示名の変更によるイベント駆動
        self.__kgmpic_layer.nameChanged.connect(
            self.pplayer_nameChangedSlot)
    
    
    def amiok(self):
        print('【KgmQpQgisIo】KgmQpDataのインスタンスへの参照は、'\
          '{} です。'.format(self._kgm_qp_data_instance))
        print('【KgmQpQgisIo】KGMデータのあるフォルダへのパスは、'\
          '{} です。'.format(self._kgm_qp_data_instance.kgmqp_folderpath))
    
    
    def set_tracklog_layer(self, tlgfile_name: str) -> str:
        """
        QGIS上のトラックログを選択／作成してレイヤ名を返す
        """
        tlg_layers = []
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                dpr = lyr.dataProvider()
            except:
                print('【set_tracklog_layer】dataProviderのないレイヤ：'\
                      '{}'.format(lyr.name()))
                pass
            else:
                src = dpr.dataSourceUri()        # レイヤのソースに
                if src.find(tlgfile_name) >= 0:  # tlgファイル名あり
                    tlg_layers.append(lyr)       # レイヤリストに追加
                else:
                    pass
        
        if len(tlg_layers) == 0:                      # 該当レイヤなし
            tlg_layer_name = self.create_tlg_layer()  # 新規作成
        elif len(tlg_layers) > 1:                     # 複数あり
            print('【KgmQpQgisIo】該当Tracklogレイヤが複数あります！：'\
                  '{}'.format(tlg_layers))
        else:
            # 以前作ったレイヤが（１つのみ）ある場合
            self.kgmtlg_layer = tlg_layers[0]
            tlg_layer_name = tlg_layers[0].name()
        
        return tlg_layer_name
    
    def create_tlg_layer(self) -> str:
        """
        トラックログのレイヤを作りその名前をインスタンス変数に入れる
        """
        
        ##### 2021/12/13: 
        #     暫定的に背景地図XYZタイルの読み込みもここで実施
        # https://docs.qgis.org/3.10/ja/docs/pyqgis_developer_cookbook/
        #         cheat_sheet.html#layers
        urlWithParams = 'type=xyz&url=https://a.tile.openstreetmap.org/%7Bz%7D/%7Bx%7D/%7By%7D.png&zmax=19&zmin=0&crs=EPSG3857'
        self.loadXYZ(urlWithParams, 'OpenStreetMap')
        
        kgmtlg_layer_name = self.create_trackpoint_layer_from_gpx()
        
        return kgmtlg_layer_name
    
    def list_existing_tlgs(self) -> list:
        """
        2022/05/26:
        既存のトラックログレイヤを探してリストを返す
        """
        tlg_layers = []
        tlg_layer_names = []
        ### kgmdir = self._kgm_qp_data_instance.kgmqp_folderpath
        
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                dpr = lyr.dataProvider()
            except:
                print('【set_tracklog_layer】dataProviderのないレイヤ：'\
                      '{}'.format(lyr.name()))
                pass
            else:
                src = dpr.dataSourceUri()        # レイヤのソースに
                
                print('【set_tracklog_layer】dataSourceUriの値は：'\
                      '{}です。'.format(src))
                
                src_parsed = self.parse_data_source_uri(src)
                
                src_filepath = src_parsed[0]     # [0]がソースファイルのフルパス
                sec_suffix = src_parsed[1]       # [1]が（tlgレイヤの）追加名
                
                if src_filepath.find('.gpx') >= 0:       # .gpxファイルあり
                    tlg_layers.append(lyr)       # レイヤリストに追加
                    tlg_layer_names.append(lyr.name())   #レイヤ名リストに追加
                    print('【list_existing_tlgs】tlgレイヤ：'\
                          '{}を追加しました。'.format(lyr.name()))
                    
                else:
                    print('【list_existing_tlgs】.gpxレイヤではありません：'\
                          '{}'.format(src_filepath))
        
        '''
        if len(tlg_layers) == 0:                      # 該当レイヤなし
            tlg_layer_name = self.create_tlg_layer()  # 新規作成
        elif len(tlg_layers) > 1:                     # 複数あり
            print('【KgmQpQgisIo】該当Tracklogレイヤが複数あります！：'\
                  '{}'.format(tlg_layers))
        else:
            # 以前作ったレイヤが（１つのみ）ある場合
            self.kgmtlg_layer = tlg_layers[0]
            tlg_layer_name = tlg_layers[0].name()
        '''
                
        return tlg_layer_names
    
    
    def parse_data_source_uri(self, dsu: str) -> list:
        """
        2022/05/26:
        dataSourceUri（ローカルファイルの）を以下の要素に分解
        １．ソースファイルのフルパス
        ２．「|」以降の部分
        """
        
        try:
            """ dsuを「|」で分割 """
            sourcefile_path, layername_suffix = dsu.split('|')
        except:
            """ 「|」がない場合（.shpなど）の処理 """
            sourcefile_path = dsu
            layername_suffix = ''
        else:
            pass
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【parse_data_source_uri】sourcefile_pathの値は、'\
                  '{} です。'.format(sourcefile_path))
            print('【parse_data_source_uri】layername_suffixの値は、'\
                  '{} です。'.format(layername_suffix))
        
        dsu_parsed = [sourcefile_path, layername_suffix]
        
        return dsu_parsed
    
    
    def find_dirname_of_layersourse(self, layername: str) -> str:
        """
        2022/05/26:
        レイヤのソースファイルのあるフォルダ名を返す
        """
        src_dirname = ''
        for lyr in QgsProject.instance().mapLayers().values():
            if lyr.name() == layername:
                try:
                    dpr = lyr.dataProvider()
                except:
                    print('【set_tracklog_layer】dataProviderのないレイヤ：'\
                          '{}'.format(lyr.name()))
                else:
                    src = dpr.dataSourceUri()        # レイヤのソース
                    print('【find_dirname_of_layersourse】dataSourceUriの値は：'\
                          '{}です。'.format(src))
                    
                    src_parsed = self.parse_data_source_uri(src)
                    
                    src_filepath = src_parsed[0]     # [0]がソースファイルのフルパス
                    sec_suffix = src_parsed[1]       # [1]が（tlgレイヤの）追加名
                    
                    src_dirname = os.path.dirname(src_filepath)
                    print('【find_dirname_of_layersourse】src_dirnameの値は：'\
                          '{}です。'.format(src_dirname))
                    
        return src_dirname
        
        
        
    
    
    def create_trackpoint_layer_from_gpx(self):
        """
        Jean-Francois-Bourdonの方法によるGPXレイヤの作成
        """
        ##### 2021/12/05:
        #    【改訂】トラックポイントはshapefileは作らずgpxレイヤとして保持
        #     作成されたgpxレイヤをKgmQpQgisIoのインスタンス変数にset
        names = ["track_points"]
        
        for dirpath, subdirs, files in os.walk(
                self._kgm_qp_data_instance.kgmqp_folderpath):
            for f in files:
                 if((".GPX" in f) or (".gpx" in f)):
                    # if(".GPX" in f):
                    # 2021/05/29：KGM-iでは「.gpx」（小文字）のためエラーに
                    gpx_filebase, gpx_fileext = os.path.splitext(f)
                    for name in names:
                        layer = iface.addVectorLayer(
                            os.path.join(dirpath, f) + \
                            "|layername=" + name, gpx_filebase, "ogr")
                        qgis_gpx_layername = gpx_filebase + " " + name
                        print(name, qgis_gpx_layername)
        
        style_file_path = os.path.join(
            self._kgm_qp_data_instance.kgmqp_root_path,
            'KGM-Qp_tracklog_red1mm.qml')
        layer.loadNamedStyle(style_file_path)
        
        ##### 2021/12/13: 【暫定】トラックログのレイヤにズーム
        layer.updateExtents()
        canvas = iface.mapCanvas()
        canvas.waitWhileRendering()
        canvas.setExtent(layer.extent())
        canvas.refresh()
        
        layer.triggerRepaint()
        iface.layerTreeView().refreshLayerSymbology(layer.id())
        
        # 【2022/02/20:要検討】インスタンス変数に保存
        self.kgmtlg_layer = layer
        return qgis_gpx_layername
    
    
    def set_pp_layer(self, ppsource_name: str) -> str:
        """
        QGIS上のPhotopointレイヤを選択／作成してレイヤ名を返す
        """
        pp_layers = []
        
        '''
        whatsthis = QgsProject.instance().mapLayers().values()
        print('mapLayers()の戻り値は、{}です。'.format(whatsthis))
        
        whatsthis2 = QgsProject.instance().mapLayersByName('')
        print("mapLayersByName('')の戻り値は、{}です。".format(whatsthis2))
        '''
        
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                dpr = lyr.dataProvider()
            except:
                print('【set_pp_layer】dataProviderのないレイヤ：'\
                      '{}'.format(lyr.name()))
                pass
            else:
                src = dpr.dataSourceUri()        # レイヤのソースに
                if src.find(ppsource_name) >= 0:  # ppファイル名あり
                    pp_layers.append(lyr)       # レイヤリストに追加
                else:
                    pass
        
        if len(pp_layers) == 0:                      # 該当レイヤなし
            if len(ppsource_name) > 0:
                ##### 2022/03/05: ソースのshpファイルはある場合
                layer_path = os.path.join(
                    self._kgm_qp_data_instance.kgmqp_folderpath, 
                    ppsource_name)
                pp_layer_name = os.path.basename(
                    self._kgm_qp_data_instance.kgmqp_folderpath) + \
                    'の撮影地点'
                layer = QgsVectorLayer(layer_path, pp_layer_name, 
                                       'ogr')
                if not layer.isValid():
                    print( "Layer failed to load!")
                else:
                    QgsProject.instance().addMapLayer(layer)
                    self.kgmpic_layer = layer
                    self._kgm_qp_data_instance.pplyr_name = layer.name()
                ##### 2021/12/13:
                #     KGM photopointのデフォルトのスタイルを読み込む
                #                -> see Programmer's Guide, p.117
                style_file_path = os.path.join(
                    self._kgm_qp_data_instance.kgmqp_root_path,
                    'KGM-Qp_photopoints_white4mm_label16pt.qml')
                layer.loadNamedStyle(style_file_path)
            else:
                ##### 2022/03/05: ソースのshpファイル自体がない場合
                # 新規作成
                pp_layer_name = self.create_point_shape_layer()
        elif len(pp_layers) > 1:                     # 複数あり
            print('【KgmQpQgisIo】該当Photopointsレイヤが複数あります！：'\
                  '{}'.format(pp_layers))
        else:
            # 以前作ったレイヤが（１つのみ）ある場合
            self.kgmpic_layer = pp_layers[0]
            pp_layer_name = pp_layers[0].name()
        
        return pp_layer_name
    
    
    def create_point_shape_layer(self):
        """
        KGM写真撮影地点のpoint shapeファイルを作成し、フィールドを定義
        --> see: PyQGIS_shapefileレイヤ作成テスト_20210315_直接地物から_
                 take2.txt          
        """        
        ##### 2021/11/06: これはフィールド定義までに限定、
        #                 フィーチャー追加は別途 
        
        path = self._kgm_qp_data_instance.kgmqp_folderpath
        
        # define fields for feature attributes. A QgsFields object is needed
        fields = QgsFields()
        ##### 属性テーブルに写真ID・写真ファイル名のフィールドを作成
        #     （2021/11/06）
        fields.append(QgsField("pic_id", QVariant.Int))
        fields.append(QgsField("pic_filename", QVariant.String))
        fields.append(QgsField("memo_text", QVariant.String))
        fields.append(QgsField("shoot_time", QVariant.String))
                                           # 暫定的に文字列で
        
        ##### 2021/11/12: レイヤ名もここで指定
        layer_name = os.path.basename(
            self._kgm_qp_data_instance.kgmqp_folderpath) + 'の撮影地点'
        
        shapefile_name = layer_name + ".shp"
        layer_path = os.path.join(path, shapefile_name)
        print("【layer_path】 ", layer_path)
        
        ##### 2021/12/09: QgsVectorFileWriter.createに
        #                （少なくともv.3.10では）バグがあるらしい
        ##### 2021/12/13: バグ回避よりQGISのver.upを選択、12/10に
        #                 v.3.16に切り替えた。
        
        """ create an instance of vector file writer, 
            which will create the vector file.
        Arguments:
        1. path to new file (will fail if exists already)
        2. field map
        3. geometry type - from WKBTYPE enum
        4. layer's spatial reference (instance of
           QgsCoordinateReferenceSystem)
        5. coordinate transform context
        6. save options (driver name for the output file, encoding etc.)
        """
        temp_layer_path = os.path.join(path, 'temp.shp')
    
        crs = QgsProject.instance().crs()
        transform_context = QgsProject.instance().transformContext()
        save_options = QgsVectorFileWriter.SaveVectorOptions()
        save_options.driverName = "ESRI Shapefile"
        save_options.fileEncoding = "UTF-8"
        
        writer = QgsVectorFileWriter.create(
          layer_path,
          fields,
          QgsWkbTypes.Point,
          crs,
          transform_context,
          save_options)
        
        
        ##### 2021/12/09:
        #  Features追加のループをここに移動
        # 「フォルダ内の全写真」listはKgmQpDataのインスタンス変数を参照
        #
        kgmdir = self._kgm_qp_data_instance.kgmqp_folderpath
        jpgpics = self._kgm_qp_data_instance.kgmqp_list_jpgpics
        tp_name = self._kgm_qp_data_instance.tlglyr_name
                  # トラックポイントレイヤ名
        gpx_tp = self.select_tp_layer(tp_name)
                  # KgmQpQgisIoのインスタンス変数を参照
        
        fet = QgsFeature()
        
        
        for ix, dummy in enumerate(jpgpics):
            """
            フォルダ内の全写真ファイルを対象にループを回す
            写真IDを続例フィールドに入れるためenumerate()を使う
            （2021/03/29） 
            """
            
            # 参照する写真の順番をixで明示的に指定
            jpg_file = os.path.join(kgmdir, jpgpics[ix])
            
            exifstr = \
              self._kgm_qp_data_instance.kgm_exif_inst.get_exif_of_image(
                  jpg_file)
            
            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('写真 {} のEXIFテーブルは、'\
                      '{} です。'.format(jpg_file, exifstr))
                
            
            
            
            
            exif_date_time = \
              self._kgm_qp_data_instance.kgm_exif_inst.get_datetime_of_image(
                  jpg_file)
            gpx_date_time = \
              self._kgm_qp_data_instance.kgm_exif_inst.conv_exifdt_to_gpxdt(
                  exif_date_time)
            
            gpx_gmy = self.get_geometry_by_utcdt(gpx_tp, gpx_date_time)
            
            
            # fet.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(10,10)))
            fet.setGeometry(gpx_gmy)
            '''
            # fet.setAttributes([ix, os.path.basename(jpg_file),'Hello!', 
                                exif_date_time])
            '''
            ##### 2022/03/06:
            #    【修正すみ】shpファイル自体を新規作成のときのみ実行
            fet.setAttributes([ix, 
                               os.path.basename(jpg_file),
                               'Hi!', 
                               exif_date_time])
            
            result = writer.addFeature(fet)
            
            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('addFeatureの結果は {} です。'.format(result))
                print('writer {} にfeature {} を追加しました'\
                      '。'.format(writer, fet))
        
        if writer.hasError() != QgsVectorFileWriter.NoError:
            print('Error when creating shapefile: ',  
                  writer.errorMessage())
        
        # delete the writer to flush features to disk
        del writer
        
        
        layer = QgsVectorLayer(layer_path, layer_name, 'ogr')
        
        if not layer.isValid():
            print( "Layer failed to load!")
        else:
            QgsProject.instance().addMapLayer(layer)
            self.kgmpic_layer = layer
            self._kgm_qp_data_instance.pplyr_name = layer.name()
        
        ##### 2021/12/13:
        #     KGM photopointのデフォルトのスタイルを読み込む
        #     -> see Programmer's Guide, p.117
        
        style_file_path = \
          os.path.join(self._kgm_qp_data_instance.kgmqp_root_path,
                       'KGM-Qp_photopoints_white4mm_label16pt.qml')
        layer.loadNamedStyle(style_file_path)
        
        
        layer.triggerRepaint()
        iface.layerTreeView().refreshLayerSymbology(layer.id())
        
        return layer_name
    
    
    def select_tp_layer(self, layer_name):
        """
        QGISの一覧からGPXのTrackPointsレイヤを選択
        """
        
        layers = QgsProject.instance().mapLayersByName(layer_name)
        
        ##### 2021/12/03: レイヤが既存の場合に対処
        if len(layers) >=1:
            tp = layers[0]
            ##### 2021/12/05:
            #     レイヤ名を取り出す処理はKgmQpQgisIo内でやる要あり？
            #     self._kgm_qp_data_instance.tlglyr_name = tp.name()
            
            ##### 2021/12/16: レイヤ自体はKgmQpQgisIoで管理
            #                 その名称の管理はKgmQpDataで
            self.kgmtlg_layer = tp
        else:
            ##### 2021/12/25:
            #    ↓これだと「object of type 'type' has no len()」
            #      エラーになるので当座「''」に戻す
            #    tp = object
            ##### 2022/06/16 tp = ''
            tp = object
        
        return tp
    
    
    def select_pp_layer(self, layer_name: str) -> object:
        """
        QGISの一覧からGPXのPhotoPointsレイヤを選択
        """
        
        layers = QgsProject.instance().mapLayersByName(layer_name)
        
        ##### 2021/12/03: レイヤが既存の場合に対処
        if len(layers) >=1:
            pp = layers[0]
            
            ##### 2021/12/13: レイヤ自体はKgmQpQgisIoで管理
            #                 その名称の管理はKgmQpDataで
            # 【2022/02/15: 一時的にコメントアウト】
            #  self.kgmpic_layer = pp
        else:
            ##### 2021/12/13: objectの変数に空文字列を入れるのは反則？
            # pp = ''
            ##### 2021/12/25:
            #    ↓これだと「object of type 'type' has no len()」エラー
            #      になるので当座「''」に戻す
            # pp = object
            pp = ''
        
        return pp
    
    
    def get_geometry_by_utcdt(self, tp, utcdt):
        """
        GPX-TrackPointsレイヤのフィーチャをUTC日付時刻で検索して
        ジオメトリを返す
        """
        xpr = '"time" = ' + "'" + utcdt + "'"
        print(xpr)
        
        rq = QgsFeatureRequest().setFilterExpression(xpr)
        for f in tp.getFeatures(rq):
            gmy = f.geometry()
            
        return(gmy)
        
    
    def get_fields(self, layer_name: str) -> list:
        """
        指定された名前のレイヤの属性テーブルのフィールドのリストを返す
        """
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【KgmQpQgisIo】photopointのレイヤ名は、'\
                  '{} です。'.format(layer_name))
                
        layers = QgsProject.instance().mapLayersByName(layer_name)
        lyr = layers[0]
        field_list = lyr.fields()
        return field_list
    
    
    
    
    
    
    def sp_feature_attributes(self, ix: int) -> list:
        """
        KGM撮影地点[ix]の属性のリスト
        """
        
        ##### 2021/11/07: 下記を参考に試し書き
        # https://docs.qgis.org/3.16/en/docs/pyqgis_developer_cookbook/
        #         vector.html#selecting-features
        ##### 2121/11/12: それをもとにリライト
        select_expression = '"pic_id" = ' + str(ix)
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('選択条件の文字列は、'\
                  '{} です。'.format(select_expression))
        
        self.kgmpic_layer.selectByExpression(
            select_expression, 
            QgsVectorLayer.SetSelection)
        
        # これはエラーになったので後回し：
        # iface.mapCanvas().setSelectionColor( QColor("yellow") )
        
        selection = self.kgmpic_layer.selectedFeatures()
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('選択されたフィーチャは、'\
                  '{} です。'.format(selection))
            print('選択されたフィーチャの属性１は、'\
                  '{} です。'.format(selection[0]))
        
        ipf_current_attrlist = selection[0].attributes()
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('返される属性リストは、'\
                  '{} です。'.format(ipf_current_attrlist))
            
        return ipf_current_attrlist
        
        
    def set_photopoint_memotext(self, ix: int, txt: str) -> None:
        """ 
        photopointの写真番号ixの属性テーブルの'memo_text'フィールドに、
        txtの内容を記入する。
        """
        ##### 2021/11/27：
        # 【重要】属性テーブルの内容を変更する際には、
        # selectしたフィーチャに変更を加えても、もとの属性テーブルに
        # 反映されない！
        # 変更対象のレイヤのデータプロバイダのchangeAttributeValues
        # メソッドを使う必要がある（らしい）。 
        # その手順は以下のとおり：
        # １．変更対象のフィールドとその値を、辞書型で用意する。
        #   attrs = { 【フィールドのインデクス番号】: 【記入する値】 }
        # ２．変更対象の地物のフィーチャIDと、上記の（辞書型）変数とを
        #  （組み合わせた辞書型の）引数にして、changeAttributeValues
        #   に渡す。
        #   pplayer.dataProvider().changeAttributeValues(
        #                                  { crnt_ppl_fid : attrs })
        # 【出典】『GIS実習オープン教材』
        # 「ベクターデータの属性情報に基づく処理」の
        # 「地物の属性情報の編集」
        #  https://gis-oer.github.io/gitbook/book/materials/python/
        #          03/03.html
        # 
        
        ##### 2021/11/27：
        #     変更対象のレイヤを確実に指定するため、KgmQpDataの
        #     インスタンス変数へのアクセッサでレイヤ名を取得
        pplname = self._kgm_qp_data_instance.pplyr_name
        layers = QgsProject.instance().mapLayersByName(pplname)
        pplayer = layers[0]
        
        ##### 2021/11/27：
        #    【要検討】変更対象の地物のフィーチャIDはselectで
        #     取っているが、これでよいか？
        #     （2021/11/27現在、とくに支障なく処理できている模様）
        select_expression = '"pic_id" = ' + str(ix)
        pplayer.selectByExpression(select_expression, 
                                   QgsVectorLayer.SetSelection)
        selection = pplayer.selectedFeatures()
        crnt_ppl_fid = selection[0].id()
        
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('pplnamedの値は、{} です。'.format(pplname))
            print('pplayerのソースは{}です。'.format(pplayer.source()))
            print('crnt_ppl_fidの値は、{} です。'.format(crnt_ppl_fid))
        
        '''
        ##### 2021/11/27：
        # 以下のcapabilities()で属性情報変更可を確認せよとの
        # 情報もあったが、capsが何かへのポインタのような値になり、
        # if文が満たされず処理がスキップされるので、当面は割愛・・・
        #【出典】
        # PyQGIS Developer Cookbook（v.3.22）6.4.3. Modify Features
        # https://docs.qgis.org/3.22/en/docs/pyqgis_developer_cookbook/
        #        vector.html#retrieving-information-about-attributes
        # 
        caps = pplayer.dataProvider().capabilities()
        if caps & QgsVectorDataProvider.ChangeAttributeValues:
            attrs = { crnt_ppl_fid : txt}
            layer.dataProvider().changeAttributeValues({ fid : attrs })
        '''
        
        attrs = { selection[0].fieldNameIndex('memo_text') : txt}
        pplayer.dataProvider().changeAttributeValues(
            { crnt_ppl_fid : attrs })
            
            
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('QgsVectorDataProvider.ChangeAttributeValuesの値は'\
                  '{}です。'.format(
                      QgsVectorDataProvider.ChangeAttributeValues))
            # print('capsの値は{}です。'.format(caps))
            print('attrsの内容は、{} です。'.format(attrs))
        
        ##### 2021/12/05: 変更を確定・保存するためにこれが必要？
        self.kgmpic_layer.commitChanges()
    
    
    def loadXYZ(self, url, name):
        """
        XYZレイヤを読み込む（2021/12/13） 
        出典：https://docs.qgis.org/3.10/ja/docs/pyqgis_developer_cookbook/
                      cheat_sheet.html#layers
        """
        rasterLyr = QgsRasterLayer("type=xyz&url=" + url, name, "wms")
        QgsProject.instance().addMapLayer(rasterLyr)
    
    
    def s2k_photopoints(self):
        """
        2021/12/26: photopointsのバルーン作成テスト
        """
        
        kml = simplekml.Kml()
        
        ##### 2021/12/26: tracklogをlinestringとして書き出し
        ls = kml.newlinestring(name='tracklog')
        tp_features = self.kgmtlg_layer.getFeatures()
        
        tlg_coords_list = []
        tlg_coords_tuple = ()
        
        for ix, f in enumerate(tp_features):
            geo= QgsGeometry.asPoint(f.geometry())
            pxy=QgsPointXY(geo)
            
            ##### 2022/01/13:
            # Web版Google Earthで始点と終点が勝手に結ばれる問題のworkaround
            # 始点のみ地下100m(?)に偽装
            # ☆終点もやりたがったが、len(tp_features)だとエラーになる
            #   ∴とりあえず終点はfor...elseの形で追記
            # tlg_coords_tuple = (pxy.x(), pxy.y())
            # tlg_coords_list.append(tlg_coords_tuple)
            if ix == 0:
                tlg_coords_tuple = (pxy.x(), pxy.y(), -100)
            else:                     
                tlg_coords_tuple = (pxy.x(), pxy.y(), 0)
            
            tlg_coords_list.append(tlg_coords_tuple)
        
        else:
            tlg_coords_tuple = (pxy.x(), pxy.y(), -100)
            tlg_coords_list.append(tlg_coords_tuple)
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【s2k_photopoints】tlg_coods_strの値は、'\
                  '{}です。'.format(tlg_coords_list))
        
        ls.coords = tlg_coords_list
        ls.extrude = 1
        ls.altitudemode = simplekml.AltitudeMode.relativetoground
        ls.style.linestyle.width = 3
        ls.style.linestyle.color = simplekml.Color.red
        
        ##### 2021/12/26: photopointsの書き出し
        pp_features = self.kgmpic_layer.getFeatures()
        
        for ix, f in enumerate(pp_features):
            
            attrlist = self.sp_feature_attributes(ix)
            
            # 2021/12/16:
            # ↓このように書くらしい
            # https://gis.stackexchange.com/questions/332026/
            #         getting-position-of-point-in-pyqgis
            geo= QgsGeometry.asPoint(f.geometry())
            pxy=QgsPointXY(geo)
            pnt = kml.newpoint(name=str(attrlist[0]), 
                               coords=[(pxy.x(),pxy.y())])
            
            ##### 2022/01/12:
            # addfileで写真データそのものもkmzに含めるよう指定
            #   https://simplekml.readthedocs.io/en/latest/kml.html#
            # pnt.description = '<img src="' + attrlist[1] +'
            #         " alt="picture" width="400" align="center" />'
            photopath =  kml.addfile(os.path.join(
                self._kgm_qp_data_instance.kgmqp_folderpath, 
                attrlist[1]))
            pnt.description = '<img src="' + photopath + \
                '" alt="picture" width="400" align="center" />'
            
        ##### 2022/01/12: 写真を含むkmzとして保存
        ##### 2022/01/13: ファイル名をフォルダ名と同じにする
        # kml.save(os.path.join(
        #          self._kgm_qp_data_instance.kgmqp_folderpath, 
        #          'pp_test.kml'))
        # kml.savekmz(os.path.join(
        #          self._kgm_qp_data_instance.kgmqp_folderpath, 
        #          'pp_test.kmz'), format=False)
        kmz_filename = os.path.basename(
            self._kgm_qp_data_instance.kgmqp_folderpath) + '.kmz'
        kml.savekmz(os.path.join(
            self._kgm_qp_data_instance.kgmqp_folderpath, 
            kmz_filename), 
            format=False)
    
    def pplayer_selectionChangedSlot(self):
        """
        【2022/02/15】
        photopointレイヤのフィーチャがマウスクリックで選択された
        イベントの処理
        """
        
        """
        ### 2022/05/12: 【これはNG】延々反復になる！
        #                KGMデータを追加／切換えたときにもこのイベントが
        #               発生するらしいのでそれに対処
        pplname = self._kgm_qp_data_instance.pplyr_name
        layers = QgsProject.instance().mapLayersByName(pplname)
        self.kgmpic_layer = layers[0]
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【pplayer_selectionChangedSlot】self.kgmpic_layerの名称は、'\
                  '{}です。'.format(self.kgmpic_layer.name))
        """
        
        selection = self.kgmpic_layer.selectedFeatures()
        
        pp_fidlist = []
        # for ix, f in enumerate(selection):
        for f in selection:
            pp_fidlist.append(f.id())
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【pplayer_selectionChangedSlot】selectionChangedが'\
                  '{}で検知されました。'.format(pp_fidlist))
            print('【pplayer_selectionChangedSlot】選択されたphotopoint'\
                  'の数は{}です。'.format(len(selection)))
            
        if len(pp_fidlist) == 0:
            # photopoint以外の地点がクリックされた場合：
            #  → 直前の選択を回復
            ix = self._kgm_qp_data_instance.current_photo_index
            select_expression = '"pic_id" = ' + str(ix)            
            self.kgmpic_layer.selectByExpression(
                select_expression, 
                QgsVectorLayer.SetSelection)
        elif len(pp_fidlist) == 1:
            # photopointの１地点のみが選択された場合：
            signaled_photo_attributes = selection[0].attributes()
            signaled_photo_index = signaled_photo_attributes[0]
                # 属性[0]が写真ID番号
            if signaled_photo_index == \
                self._kgm_qp_data_instance.current_photo_index:
                # もと選択されていた写真番号と同一：何もしない
                pass
            else:
                # もと選択されていた写真番号と異なる：そこへ移動
                if self._kgm_qp_data_instance._debug_mode == 'Y':
                    print('【pplayer_selectionChangedSlot】新規に'\
                          '写真番号{}が選択されました'\
                          '。'.format(signaled_photo_index))
                
                # kqm_qp_coreのcurrent_photo_indexを更新後に
                # メイン窓の写真ID番号欄更新メソッドを呼ぶ
                self._kgm_qp_data_instance.current_photo_index = \
                    signaled_photo_index
                self._kgm_qp_data_instance.photopoint_to_be_shown_update()
    
    def pplayer_nameChangedSlot(self):
        """
        【2022/03/06】
        photopointレイヤのレイヤ名が変更された
        イベントの処理
        """
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【pplayer_nameChangedSlot】レイヤ名の変更が'\
                  '{}で検知されました。'.format(self.kgmpic_layer))
            
        self._kgm_qp_data_instance.pplyr_name = self.kgmpic_layer.name()
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【pplayer_nameChangedSlot】新しいレイヤ名は'\
                  '{}です。'.format(self._kgm_qp_data_instance.pplyr_name))
    
    def tplayer_nameChangedSlot(self):
        """
        【2022/03/06】
        tracklogレイヤのレイヤ名が変更された
        イベントの処理
        """
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【tplayer_nameChangedSlot】レイヤ名の変更が'\
                  '{}で検知されました。'.format(self.kgmtlg_layer))
            
        self._kgm_qp_data_instance.tlglyr_name = self.kgmtlg_layer.name()
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【tplayer_nameChangedSlot】新しいレイヤ名は'\
                  '{}です。'.format(self._kgm_qp_data_instance.tlglyr_name))
    
    def set_current_kgmqp_data_path(self, crnt_cbx_text: str) -> str:
        """
        【2022/04/24】
        comboBox_TrackLogNameによりトラックログが変更されたことに基づく
        現在操作対象となるKGMデータセットの切替えのために、
        トラックログレイヤのソースのディレクトリのパスを返す
        
        """
        crnt_tp_layer = self.select_tp_layer(crnt_cbx_text)
        
        ##### 2022/06/16 ここでエラーが出た
        try:
            crnt_tp_layer_source = crnt_tp_layer.source()
        except:
            print('【set_current_kgmqp_data_path】現在のcrnt_cbx_textの値は'\
                  '{}です。'.format(crnt_cbx_text))
            print('【set_current_kgmqp_data_path】現在のcrnt_tp_layerの値は'\
                  '{}です。'.format(crnt_tp_layer))
            # crnt_tp_layer_source = self.kgmtlg_layer
            # crnt_tp_layer_source = crnt_tp_layer.source()
            crnt_kgm_dir = self._kgm_qp_data_instance.kgmqp_folderpath
            return crnt_kgm_dir
        
        # 【これはNG】crnt_tp_layer_source = crnt_tp_layer.decodedSource()
        
        crnt_kgm_dir = os.path.dirname(crnt_tp_layer_source)
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【set_current_kgmqp_data_path】現在のtpレイヤのソースは'\
                  '{}です。'.format(crnt_tp_layer_source))
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【set_current_kgmqp_data_path】現在のtpレイヤのフォルダは'\
                  '{}です。'.format(crnt_kgm_dir))
        
        return crnt_kgm_dir
    
    
    def save_map_as_image(self, map_export_path: str) -> None:
        """
        【2022/02/26】
        現在表示中の地図をPNG画像ファイルに書き出す
        """
        canvas = iface.mapCanvas()
        canvas.saveAsImage(map_export_path)
    
    '''
    def save_pic_as_image(self, pic_export_path: str, ix: int) -> None:
        """
        【2022/02/26】
        現在表示中の写真を（将来は番号付きで）書き出す
        """
        pp_layer = self.kgmpic_layer
        pp_attrlist = self.sp_feature_attributes(ix)
        pp_pic_filename = pp_attrlist[1]
        
        pp_pic_folder = self._kgm_qp_data_instance.kgmqp_folderpath
        
        src_fullpath = os.path.join(pp_pic_folder, pp_pic_filename)
        copy_fullpath = pic_export_path
        shutil.copyfile(src_fullpath, copy_fullpath)
    '''
    
    
